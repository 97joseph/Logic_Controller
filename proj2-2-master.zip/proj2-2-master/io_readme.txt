IO-device.circ contains a IO device that is connected to our CPU and has a pre-installed program.

Our IO device acts as an accumulator for $s0, so that anything that is ever stored into $s0 can be be totaled and displayed in a hex display array.