ECS-154: Computer Architecture
=======
Taken Fall 2014

Introduction to digital design. Interfacing of devices for I/O, memory and memory management. Input/output programming, via wait loops, hardware interrupts and calls to operating system services. Hardware support for operating systems software. 
